import { Component } from '@angular/core';
import { NavController, AlertController } from 'ionic-angular';
//Import AngularFireDatabase from angularfire2. Possibly, import also FirebaseListObservable and/or FirebaseObjectObservable if you need to bind to a list or an object.
import { AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database';
//import * as firebase from 'firebase/app';
import { AuthProvider } from '../../providers/auth/auth';
import { CrearFacturasPage } from '../crear-facturas/crear-facturas';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})

export class HomePage {

  // usuario
  user = null;
  public email: string;
  public password: string;
  // Recuperar la lista
  topics: FirebaseListObservable<any[]>;
  billList: FirebaseListObservable<any>;
  constructor(public navCtrl: NavController, public db: AngularFireDatabase, private auth: AuthProvider,
  public alertCtrl: AlertController) {

    // Obtenemos el estado del usuario
    this.auth.getAuthState().subscribe((user) => this.user = user);
    // Mostrando listado de topicos
    this.topics = this.db.list('/topics');
    this.billList = this.db.list('/facturas');
    /* Desengancharse
    const unsubscribe = firebase.auth().onAuthStateChanged((user) => {
        if (!user) {
          this.rootPage = 'login';
          unsubscribe();
        } else{
            this.rootPage = HomePage;
            unsubscribe();
          }
      });*/
  } // Fin del constructor

  loginWithMailPassword() {
    this.auth.loginWithMailPassword(this.email, this.password);
  }
  loginWithGoogle() {
    this.auth.loginWithGoogle();
  }

  newBill() { //Creamos nueva factura mediante metodo push
    this.navCtrl.push(CrearFacturasPage);
  }

  promptPayment(billId: string) {
    let alert = this.alertCtrl.create({
      message: "Marcar como pagada?",
      buttons: [{
        text: 'Cancel',
      },
      {
       text: 'Marcar como pagada',
       handler: data => { this.billList.update(billId, { paid: true });
      }
    }]
  });
  alert.present();
}



}
