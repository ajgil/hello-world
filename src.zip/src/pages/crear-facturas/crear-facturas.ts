import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database';

/**
 * Generated class for the CrearFacturasPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-crear-facturas',
  templateUrl: 'crear-facturas.html',
})
export class CrearFacturasPage {

  // listado de las facturas
  billList: FirebaseListObservable<any>;
  constructor(public navCtrl: NavController, public navParams: NavParams,
    public db: AngularFireDatabase) {

    //binding al listado 
    this.billList = db.list('/facturas');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CrearFacturasPage');
  }

  createBill(name, amount, dueDate) { 
    this.billList.push({ 
      name: name, 
      amount: amount, 
      dueDate: dueDate, 
      paid: false }).then(newBill => 
        { this.navCtrl.pop();
        }, error => { console.log(error);
      });
  }
  
}
