import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CrearFacturasPage } from './crear-facturas';

@NgModule({
  declarations: [
    CrearFacturasPage,
  ],
  imports: [
    IonicPageModule.forChild(CrearFacturasPage),
  ],
})
export class CrearFacturasPageModule {}
