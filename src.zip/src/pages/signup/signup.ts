import { Component } from '@angular/core';
import { NavController, NavParams, IonicPage, AlertController, Loading, LoadingController } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthProvider } from '../../providers/auth/auth';
import { EmailValidator } from '../../validators/email';
import { PwdValidator } from '../../validators/pwd';
import { AgeValidator } from '../../validators/age';
import { HomePage } from '../home/home';
//import { PreferencesPage} from '../preferences/preferences';

/**
 * Generated class for the SignupPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

 @IonicPage ({
	name: 'signup'
})
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})

export class SignupPage {
	
	public signupForm: FormGroup;
	loading: Loading;
  
  constructor(public navCtrl: NavController, public navParams: NavParams, 
	public authProvider: AuthProvider, public formBuilder: FormBuilder,
	public loadingCtrl: LoadingController, public alertCtrl: AlertController) {
  
		this.signupForm = formBuilder.group({
				tipo: ['', Validators.required],
				genero: ['', Validators.required],
				age: ['', AgeValidator.isValid ],
				email: ['', Validators.compose([Validators.required, EmailValidator.isValid])],
				password: ['', Validators.compose([Validators.minLength(8), Validators.required, PwdValidator.isValid])],
				password2: ['', Validators.compose([Validators.minLength(8), Validators.required, PwdValidator.isValid])]
		});
	  
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SignupPage');
  }

  // Parametros del perfil de usuario al provider
  signupProfile(){
	  if (!this.signupForm.valid){
		console.log(this.signupForm.value);
	  } else {		
				this.authProvider.signupProfile(
					this.signupForm.value.tipo,
					this.signupForm.value.genero,
					this.signupForm.value.age,
					this.signupForm.value.email, 
					this.signupForm.value.password,
					this.signupForm.value.password2
					)
				.then(() => {
					this.loading.dismiss().then( () => {
					this.navCtrl.setRoot(HomePage);
					//this.navCtrl.setRoot(PreferencesPage);
					});
				}, (error) => {
					this.loading.dismiss().then( () => {
					let alert = this.alertCtrl.create({
						message: error.message,
						buttons: [
						{
							text: "Ok",
							role: 'cancel'
						}
						]
					});
					alert.present();
					});
				});
				this.loading = this.loadingCtrl.create();
				this.loading.present();
			}
		}
}

