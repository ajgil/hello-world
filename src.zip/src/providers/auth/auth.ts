import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
// AngularFirebase 2v4
import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase/app';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AuthProvider {
  private authState: Observable<firebase.User>
  private currentUser: firebase.User;
  constructor(public afAuth: AngularFireAuth) {
    this.authState = this.afAuth.authState;
    this.authState.subscribe(user => {
      if (user) {
        this.currentUser = user;
      } else {
        this.currentUser = null;
      }
    });
  }
  getAuthState() {
    return this.authState;
  }

 //login mail y password: 2 parametros para realizar login, el mail (o usuario) y la pass
  login(email: string, password: string){
    return this.afAuth.auth.signInWithEmailAndPassword(email, password);
  }

 loginWithMailPassword(email: string, password: string) {
    //creamos el login a firebase utilizando el metodo que recibe mail y pass
      return this.afAuth.auth.signInWithEmailAndPassword(email, password);
      // asi se hace con libreria firebase
      //return firebase.auth().signInWithEmailAndPassword(email, password);
  }  
 
  // login con google
  loginWithGoogle() {
  return this.afAuth.auth.signInWithPopup(
    new firebase.auth.GoogleAuthProvider());
}

  // Alta usuarios y profesionales
  signupProfile(tipo: string, genre: string, age: number,
            email: string, password: string, password2: string): firebase.Promise<any> {
	  return this.afAuth.auth.createUserWithEmailAndPassword(email, password) 
	  .then ( newUser => {
		  firebase.database().ref('/users').child(newUser.uid)
		    .set({
          tipo: tipo,
          genre: genre,
          age: age,
          email: email});
     });
  }


}
