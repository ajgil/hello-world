export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCL4ctt76o8w6bBUCxZBHuUfYpwk759Jac",
	authDomain: "stockapp-6feb9.firebaseapp.com ",
	databaseURL: "https://stockapp-6feb9.firebaseio.com",
	storageBucket: "stockapp-6feb9.appspot.com",
	messagingSenderId: "459899766638"
  }
};
