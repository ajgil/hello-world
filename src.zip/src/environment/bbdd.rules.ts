/*{
  "rules": {
    "topics": {
      ".read": true,
      ".write": false
    },
    "userProfile": {
      "$uid": {
        ".read": "auth != null && $uid === auth.uid",
        ".write": "$uid === auth.uid"
      }
  	}
  }
}*/