import { FormControl } from '@angular/forms';

export class PwdValidator {

  static isValid(control: FormControl){
    const re = /^([a-zA-Z0-9_-]{8,18})$/.test(control.value);

    if (re){
      return null;
    }

    return {
      "invalidPassword": true
    };

  }
}